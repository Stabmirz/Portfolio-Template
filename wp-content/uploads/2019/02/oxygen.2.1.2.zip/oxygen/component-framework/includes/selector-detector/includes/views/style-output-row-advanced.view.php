<div class="oxygen-control-row oxygen-control-row-bottom-bar"
	ng-show="!iframeScope.selectorDetector.mode&&isActiveName('ct_inner_content')&&iframeScope.ajaxVar.ctTemplate">
	<div class="oxygen-selector-detector-style-button"
		ng-click="enableSelectorDetectorMode()">
		<?php _e("Style Output", "oxygen"); ?>
	</div>
</div>