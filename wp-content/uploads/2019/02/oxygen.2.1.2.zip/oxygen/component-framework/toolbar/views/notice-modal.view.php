<div id="ct-notice-modal"
	ng-class="{'ct-show-notice':iframeScope.noticeModalVisible}">
	<div class="ct-notice-modal-inner-wrap ct-warning">
		<div id="ct-notice-content"></div>
		<div class="ct-hide-notice-icon"
			ng-click="iframeScope.hideNoticeModal()"></div>
	</div>
</div>